-- You can enter a few SQL examples here.
-- You can move and size the example window,
-- and you can disable/enable it in the View menu.
-- Each pane has its own window.
-- The example window is saved whenever you go to another
-- pane or when you terminate the program.
 