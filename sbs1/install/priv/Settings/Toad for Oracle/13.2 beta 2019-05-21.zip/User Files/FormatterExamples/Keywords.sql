/*  The examples below are editable and saved on a per-tab basis */

SELECT aaa, bbb, cccc, SIN (x) FROM mytab; 