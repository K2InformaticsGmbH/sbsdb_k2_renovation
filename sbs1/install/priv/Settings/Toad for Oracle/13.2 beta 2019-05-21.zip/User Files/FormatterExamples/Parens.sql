/*  The examples below are editable and saved on a per-tab basis */

DECLARE
    a1                             NUMBER
                                       := f (
                                              aaaaaa,
                                              bbbbbbbb,
                                              cccccccccccc);
    a2                             NUMBER
                                       := f (
                                              aaaaaaaaaaaaaaaaaaaaaaa,
                                              bbbbbbbbbbbbbbbbbbbbbbbbb,
                                              ccccccccccccccccccccccccccccccccc);
    a3                             NUMBER := f (g (h (x)));
    a4                             NUMBER := fffffffffffffffffffff (ggggggggggggggggggggggg (hhhhhhhhhhhhhhhhhhhhhhh (xxxxxxxxxxxxxxxxxxxxxxxxx)));
    a5                             NUMBER := fffffffffffffffffffff (ggggggggggggggggggggggg (hhhhhhhhhhhhhhhhhhhhhhh (xxxxxxxxxxxx, xxxxxxxxxxxxx)));

    TYPE frcflg_rt IS RECORD
    (
        last_name CHAR (1),
        first_name CHAR (1),
        middle_initial CHAR (1),
        job_id CHAR (1),
        changed_by CHAR (1),
        changed_on CHAR (1)
    );
BEGIN
    fffffffffffffffffffff (ggggggggggggggggggggggg (hhhhhhhhhhhhhhhhhhhhhhh (xxxxxxxxxxxx, xxxxxxxxxxxxx)));
    a := NVL (x, 100);
    a := NVL (xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx.yyyyyyyyyyyyyyyyyyyyyyyy.zzzzzzzzzzzzzzzz, 100);
    a := other (x, 100);
    a := other (xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx.yyyyyyyyyyyyyyyyyyyyyyyy.zzzzzzzzzzzzzzzz, 100);
    a := DECODE (x,  1, a,  2, b,  5, d,  def);
    a := DECODE (xxxxxxxxxxxxxxxxxxx,  1, aaaaaaaaaaaaaaaaaaaaa,  2, bbbbbbbbbbbbbbbbbbbbb,  5, dddddddddddddddddddddddd,  def);
END;

SELECT x
  FROM tab
 WHERE NOT EXISTS
           (SELECT u
              FROM v
             WHERE NOT (a,
                        b,
                        c) IN (SELECT k
                                 FROM l
                                WHERE z = 1));

SELECT f (1),
       g (2),
       h (
           3,
           4,
           5)
  FROM tab;

INSERT INTO building_blocks (a)
     VALUES (NEW shape ('my_shape', 4));

INSERT INTO tab
     VALUES (1);

INSERT INTO building_blocks (
                a,
                b,
                c)
     VALUES (
         1,
         2,
         3);

INSERT INTO building_blocks (
                a,
                b,
                c,
                d,
                e)
     VALUES (
         1,
         2,
         3,
         4,
         5);

INSERT INTO building_blocks (
                aaaaaaaaaaaaaaaa,
                bbbbbbbbbbbbbb,
                cccccccccccccccc,
                ddddddddddddddddd,
                eeeeeeeeeeeee)
     VALUES (
         f (1),
         g (2),
         h (
             3,
             4,
             5));

INSERT INTO building_blocks
    SELECT aaaaaa,
           bbbb,
           cccccc,
           ddddd
      FROM mytab,
           histab,
           hertab
     WHERE histab.col1 = hertab.col2;

INSERT INTO building_blocks
    SELECT aaaaaaaaaaaaaaaa,
           bbbbbbbbbbbbbbbbbbb,
           cccccccccccccccccc,
           dddddddddddddddd,
           eeeeeeeeeeeeeee,
           fffffffffffffffffffffffffff
      FROM mytab,
           histab,
           hertab
     WHERE histab.col1 = hertab.col2;

CREATE FUNCTION asja.dd (cfin IN INTEGER)
    RETURN NUMERIC
IS
BEGIN
    NULL;
END;

CREATE FUNCTION asja.dd (
    cfin                           IN     INTEGER,
    cfout                             OUT INTEGER,
    cfinout                        IN OUT INTEGER)
    RETURN NUMERIC
IS
BEGIN
    NULL;
END;

CREATE FUNCTION asja.dd (
    cfin                           IN            INTEGER,
    cfout                             OUT        INTEGER,
    cfout                             OUT NOCOPY INTEGER,
    cfinout                        IN OUT NOCOPY INTEGER,
    cfinout                        IN OUT        INTEGER)
    RETURN NUMERIC
IS
BEGIN
    NULL;
END;

CREATE TABLE t (a NUMBER);

CREATE TABLE t
(
    a NUMBER,
    b NUMBER,
    c NUMBER
);

CREATE TABLE t
(
    aaaaaaaaaaaaaaaaaaaaaaa NUMBER,
    bbbbbbbbbbbbbbbbbbbb NUMBER,
    ccccccccccccccccccc NUMBER
); 