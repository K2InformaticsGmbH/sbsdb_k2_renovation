TYPE tcdrinfommsc IS     RECORD
    (
        price                          VARCHAR2                                         (     10          )     ,
        storageduration                                                                            VARCHAR2                                         (     10          )     ,
        layerspecificattr                                                                                      VARCHAR2                                         (     10          )     ,
        deliveryreadrepreqind                                                                                                          VARCHAR2                                         (     10          )     ,
        numofnotification                                                                                      VARCHAR2                                         (     10          )     ,
        numhomerecipients                                                                                      VARCHAR2                                         (     10          )     ,
        numnonhomeincountryrecipients                                                                                                                                                  VARCHAR2                                         (     10          )     ,
        numinternationalrecipients                                                                                                                                   VARCHAR2                                         (     10          )     ,
        numemailrecipients                                                                                           VARCHAR2                                         (     10          )     ,
        numshortcoderecipients                                                                                                               VARCHAR2                                         (     10          )     ,
        messagesize                                                        VARCHAR2                                         (     10          )     ,
        durationofstorage                                                                                      VARCHAR2                                         (     10          )     ,
        messagepriority                                                                            VARCHAR2                                         (     254               )     ,
        messageclass                                                             VARCHAR2                                         (     254               )     ,
        messagecontent                                                                       VARCHAR2                                         (     254               )     ,
        numofnotifications                                                                                           VARCHAR2                                         (     10          )     ,
        numofconversions                                                                                 VARCHAR2                                         (     10          )     ,
        mmsidentifier                                                                  VARCHAR2                                         (     254               )     ,
        fwdcopycopyind                                                                       VARCHAR2                                         (     10          )     ,
        contentrequestid                                                                                 VARCHAR2                                         (     254               )     ,
        outgoinginterfaceid                                                                                                VARCHAR2                                         (     254               )     ,
        deliveryreadreportreqind                                                                                                                         VARCHAR2                                         (     10          )     ,
        freetext                                         VARCHAR2                                         (     1000                    )     ,
        mm7linkedid                                                        VARCHAR2                                         (     254               )     ,
        prepaidfreetext                                                                            VARCHAR2                                         (     254               )     ,
        useragent                                              VARCHAR2                                         (     254               )     ,
        transcodingid                                                                  VARCHAR2                                         (     254               )     ,
        cdrrecordtype                                                                  VARCHAR2                                         (     254               )     ,
        promotionplan                                                                  VARCHAR2                                         (     254               )     ,
        tariffclass                                                        VARCHAR2                                         (     254               )
    )     ; 