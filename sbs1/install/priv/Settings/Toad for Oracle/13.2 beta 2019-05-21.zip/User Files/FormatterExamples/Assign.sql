/*  The examples below are editable and saved on a per-tab basis */

BEGIN
    a := 1;
    a := bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb;
    my_variable_one := 1;
    my_variable_two := var_a + 361;
    xyz := func (arg1);
    uvvvvvvvvvvvvvvvvvvvvvvvvw := ffffffffff (aaaaaaaaaaaaaaaaaaaaaaaaaaa, bbbbbbbbbbbbbbbbbbbbb, cccccccccc, dddddddddd);

    BEGIN
        a := 1;
        a := bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb;
        my_variable_one := 1;
        my_variable_two := var_a + 361;
        xyz := func (arg1);
        uvvvvvvvvvvvvvvvvvvvvvvvvw := ffffffffff (aaaaaaaaaaaaaaaaaaaaaaaaaaa, bbbbbbbbbbbbbbbbbbbbb, cccccccccc, dddddddddd);

        BEGIN
            a := 1;
            a := bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb;
            my_variable_one := 1;
            my_variable_two := var_a + 361;
            xyz := func (arg1);
            uvvvvvvvvvvvvvvvvvvvvvvvvw := ffffffffff (aaaaaaaaaaaaaaaaaaaaaaaaaaa, bbbbbbbbbbbbbbbbbbbbb, cccccccccc, dddddddddd);
        END;
    END;
END;

UPDATE titles
SET    ttl_descriptionfffffffff = a,
       z = b,
       u = d,
       v =
           (SELECT descrshort
            FROM   hrsdon.ps_na_name_prefix@batch.ccci.org
            WHERE  ttl_code = name_prefix),
       updated_sdate = sysffffffffffffffffffffffffffffffffffdate,
       updated_by = 'MIGDBA';

BEGIN
    BEGIN
        tmpvarvar3 := 0;
    END;

    BEGIN
        tmp2 := 0;
        tmpvar1 := 0;
        tmpvarvar3 := 0;
    END;

    BEGIN
        tmp2 := 0;
        tmpvar1 := 0;
        tmpvarvar3 := 0;
    END;

    BEGIN
        t := 0;
    END;

    BEGIN
        tmpvarvar3 := 0;
        tmpvar1 := 0;
        tmp2 := 0;
    END;

    BEGIN
        tmpvar1 := 0;
        tmp2 := 0;
        tmpvarvar3 := 0;
        tmpvar1 := 0;
        tmp2 := 0;
        tmpvarvar3 := 0;
        tmpvar1 := 0;
        tmp2 := 0;
        tmpvarvar3 := 0;
    END;
END; 