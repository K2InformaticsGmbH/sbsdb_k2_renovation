  /************************************************************************
   %BodyProcName%
   Created: %DateTime% by %UserName%
   Purpose:
  ************************************************************************/
  FUNCTION %BodyProcName%%BodyProcParams% RETURN %BodyProcReturn% IS
  BEGIN
    RETURN NULL;
  END %BodyProcName%;

