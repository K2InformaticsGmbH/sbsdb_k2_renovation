  /************************************************************************
   %BodyProcName%
   Created: %DateTime% by %UserName%
   Purpose:
  ************************************************************************/
  MEMBER FUNCTION %BodyProcName%%BodyProcParams% RETURN %BodyProcReturn% IS
  BEGIN
    RETURN NULL;
  END %BodyProcName%;

