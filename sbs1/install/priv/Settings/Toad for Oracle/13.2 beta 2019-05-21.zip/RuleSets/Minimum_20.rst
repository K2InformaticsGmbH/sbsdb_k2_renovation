<RULESET  title="Top 20" version="11.0">
<PROPERTIES>
<SUMMARY>
<RULESET_TYPE>Quest</RULESET_TYPE>
<AUTHOR>Quest Software</AUTHOR>
<CREATED>39547.3996166319</CREATED>
<MODIFIED>39547.402571088</MODIFIED>
<COMMENTS>This rule set tests your code against a core subset of rules in the Code Analysis universe including Code Correctness, Code Efficiency, Maintainability, Program Structure, and Readability.</COMMENTS>
<RULESET_TOTAL>20</RULESET_TOTAL>
</SUMMARY>
</PROPERTIES>
<RULES >
<RULE  rid="3005"/>
<RULE  rid="3801"/>
<RULE  rid="3803"/>
<RULE  rid="3806"/>
<RULE  rid="4003"/>
<RULE  rid="4213"/>
<RULE  rid="4603"/>
<RULE  rid="4809"/>
<RULE  rid="4812"/>
<RULE  rid="5001"/>
<RULE  rid="5002"/>
<RULE  rid="5401"/>
<RULE  rid="5402"/>
<RULE  rid="5801"/>
<RULE  rid="5805"/>
<RULE  rid="5807"/>
<RULE  rid="5816"/>
<RULE  rid="6405"/>
<RULE  rid="6406"/>
<RULE  rid="6801"/>
</RULES>
</RULESET>
