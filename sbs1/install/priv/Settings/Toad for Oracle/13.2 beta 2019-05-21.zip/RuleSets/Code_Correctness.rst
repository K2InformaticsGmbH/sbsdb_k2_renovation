<RULESET title="Code Correctness" version="11.0">
  <PROPERTIES>
    <SUMMARY>
      <RULESET_TYPE>Quest</RULESET_TYPE>
      <AUTHOR>Quest Software</AUTHOR>
      <CREATED>38447.6739052778</CREATED>
      <MODIFIED>38447.6740753241</MODIFIED>
      <COMMENTS>This rule set helps locate areas in your code that have a higher likelihood of error.</COMMENTS>
      <RULESET_TOTAL>37</RULESET_TOTAL>
    </SUMMARY>
  </PROPERTIES>
  <RULEFILTER>
    <TYPE Type="0" />
  </RULEFILTER>
  <RULES>
    <RULE rid="*" />
  </RULES>
</RULESET>
